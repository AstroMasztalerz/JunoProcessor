
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.Buffer;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tomasz Masztalerz
 */
public class LoadImage {

    
  
        

private static String getFileExtension(String fullName) {
    
    String fileName = new File(fullName).getName();
    int dotIndex = fileName.lastIndexOf('.');
    return (dotIndex == -1) ? "" : fileName.substring(dotIndex + 1);
}


public static BufferedImage readImg(File f) throws IOException
{
    if (getFileExtension(f.getName()).equalsIgnoreCase("png")); //if input image is PNG
    {
        return ImageIO.read(f);
    }
    
}
}