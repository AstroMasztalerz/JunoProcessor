package swingapplication;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MenuClass {
    
    /** Creates a new instance of MenuClass */
    public MenuClass() {
        JFrame frame = new JFrame();
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        String Mlabs[] = { "Menu A", "Menu B", "Menu C", "Help" };
        String Elabs[] = { "Elem 1", "Elem 2", "Elem 3" };
        
        JMenuBar jmb = new JMenuBar();		//menu bar, we add elements to this bar
        for (int i=0; i<Mlabs.length; i++) {
            JMenu jm = new JMenu(Mlabs[i]);         //first level menu
            jm.setMnemonic(Mlabs[i].charAt(i));     //set shortcut (ALT+char)
            for (int j=0; j<Elabs.length - 1; j++) {
                JMenuItem jmi = new JMenuItem(Mlabs[i]+"."+Elabs[j]);	//second level menu...
                jm.add(jmi);						//...and adding it to first level menu
            }
            jm.addSeparator();					//seaparator between menu elements
            JMenu jmx = new JMenu(Mlabs[i]+"."+Elabs[Elabs.length - 1]);
            ButtonGroup bg = new ButtonGroup();
            for (int k=0; k<4; k++) {
                JRadioButtonMenuItem jrbmi = new JRadioButtonMenuItem("X "+k, true);
                bg.add(jrbmi);
                jmx.add(jrbmi);
            }                
            jm.add(jmx);
            jmb.add(jm);                            //add element of first level menu to the menu bar
        }
        frame.setJMenuBar(jmb);                     //add menu bar to the frame
        
        JComponent comp = (JComponent)frame.getContentPane();
        comp.setLayout(new GridLayout(1, 1));
        JLabel jl = new JLabel("MENU", JLabel.CENTER);
        jl.setFont(new Font("TimesRoman", Font.BOLD, 36));
        comp.add(jl);
        
        frame.setSize(300,150);
        frame.setVisible(true);        
    }
    
}
