
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tomasz Masztalerz
 */
public class SaveImg {
    

public static void toFile(String path) throws IOException
{
ImageIO.write(Engine.getTempDisp(),"png", new File(path));
}

public static void toFilesRGB(String path) throws IOException
{
    ImageIO.write(Engine.getSpectralChannels()[0],"png",new File(path+"R.png"));  //saves Red channel
     ImageIO.write(Engine.getSpectralChannels()[1],"png",new File(path+"G.png")); //saves Green channel
      ImageIO.write(Engine.getSpectralChannels()[2],"png",new File(path+"B.png")); //saves Blue channel
}
}