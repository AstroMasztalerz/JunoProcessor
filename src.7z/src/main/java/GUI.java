
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.WindowConstants;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tomasz Masztalerz
 */
public class GUI {
    
    
    JFrame jf= new JFrame("GUI Window");
    JComponent jc=(JComponent) jf.getContentPane();
    JButton jb=new JButton("JAK");
    JMenuBar jmb=new JMenuBar();
     String Mlabs[] = { "File", "Processing", "Directories"};
      String FileLabs[] = { "Load IMG", "Elem 2", "Elem 3" };
    
    public GUI()
    {
        jf.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        jc.add(jb);
        

            JMenu jm = new JMenu(Mlabs[0]);  
            
             for (int j=0; j<FileLabs.length - 1; j++) {
             ButtonGroup bg = new ButtonGroup();
          
                JRadioButtonMenuItem jrbmi = new JRadioButtonMenuItem(FileLabs[j],true);
                bg.add(jrbmi);
                jm.add(jrbmi);
            }                
            
            
            jmb.add(jm);
            
            
        jf.add(jmb);
        jf.show();
    }
    
}

