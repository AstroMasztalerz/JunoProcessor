
import com.jhlabs.image.BlurFilter;
import com.jhlabs.image.BoxBlurFilter;
import com.jhlabs.image.UnsharpFilter;
import java.awt.Graphics;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import org.imgscalr.Scalr;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Tomasz Masztalerz
 */

public class Engine {
public static BufferedImage tempDisp;
public static String lbl;
public static boolean processed;
public static BufferedImage[] spectralChannels;
public static BufferedImage rgbCompiled;
public static String RAWfilePath;
public static BufferedImage RGB;
public static boolean IsRGBCompiled;

    static void setTempDisp(BufferedImage tempDisp) {
       Engine.tempDisp=tempDisp; 
       System.out.println(tempDisp.getWidth());
    }
    
     static BufferedImage getTempDisp() {
       return Engine.tempDisp; 
     
    }
    
    static void save() throws IOException
    {
        ImageIO.write(tempDisp, "png", new File ("C:/Users/temp.png"));
    }
    
    static void setLbl(String lbl)
    {
        Engine.lbl=lbl;
    }
    static String getLbl()
    {
        return Engine.lbl;
    }
    
   
    
    static BufferedImage [] AssembleFrames(BufferedImage RAW) throws IOException //this is to slice and re-assemble from RAW Buffered Image to sliced 3 R, G and B Buffered Images
    {   IsRGBCompiled=false;
    
        GUI_Window.setRGBButtonState(false); //allows to turn on RGB button in GUI
        int HeightMax=RAW.getHeight();
       ImageStack stack= new ImageStack(new imageForStack("BLUE", RAW.getWidth(), 128, RAW.getSubimage(0, 0, RAW.getWidth(), 128) )); //creates a new image stack, with first framelet (B filter), 128 pix high
       int currentHeight=128;
       String [] filterNames={"BLUE","GREEN","RED"};
       
            while (currentHeight<HeightMax-128)
            {
                stack.push(new imageForStack(filterNames[(currentHeight/128)%3],RAW.getWidth(), 128, RAW.getSubimage(0, currentHeight, RAW.getWidth(),128))); //slice image into 128 pix high framelets
                currentHeight+=128; //move by 128
          
            }
       BufferedImage [] output=new BufferedImage[3];
       output[0]=new BufferedImage(RAW.getWidth(), RAW.getHeight()/3, BufferedImage.TYPE_BYTE_GRAY); //Blue out
        Graphics B = output[0].getGraphics(); //graphics for B
       output[1]=new BufferedImage(RAW.getWidth(), RAW.getHeight()/3, BufferedImage.TYPE_BYTE_GRAY); //Green out
       Graphics G = output[1].getGraphics(); //graphics for G
       output[2]=new BufferedImage(RAW.getWidth(), RAW.getHeight()/3, BufferedImage.TYPE_BYTE_GRAY); //RedOut
        Graphics R = output[2].getGraphics(); //graphics for R
     currentHeight=0;
       while (stack.isEmpty()==false) //while data is available
       {
          
                B.drawImage(stack.pop().getImg(),0,((RAW.getHeight()/3)-currentHeight),null);
             
           
                    
              if (stack.isEmpty()==false)
              {
                  
                G.drawImage(stack.pop().getImg(),0,((RAW.getHeight()/3)-currentHeight),null);
               
                
              }
              if (stack.isEmpty()==false)
              {
                   //gets next Image from stack
                R.drawImage(stack.pop().getImg(),0,((RAW.getHeight()/3)-currentHeight),null);
              //System.out.println("Moved while loading");
              }
          currentHeight+=126; //move by next 128 pixels and overlay of 2 pix
              
       }
             
         //    ImageIO.write(output[1], "png", new File ("D:/file.png")); //saves test output on D drive location, from Green spectral channel
            // processed=true;
          
             spectralChannels=output; //sends the assembled images to a spectralChanenls variable which stores them
             tempDisp=spectralChannels[0];  
           Engine.tempDisp=output[0];
           GUI_Window.setImagePrev(output[1]); //sets the resulting Green channel image to preview window
             
       return output;
  
    }
    
    
    
    
    
    static void assembleRGB() throws IOException
    {
        
        BufferedImage channel0=new BufferedImage(spectralChannels[0].getWidth(),spectralChannels[0].getHeight(), BufferedImage.TYPE_INT_ARGB);
channel0.getGraphics().drawImage(spectralChannels[0],0,0,null);

        BufferedImage channel1=new BufferedImage(spectralChannels[1].getWidth(),spectralChannels[1].getHeight(), BufferedImage.TYPE_INT_ARGB);
channel1.getGraphics().drawImage(spectralChannels[1],0,0,null);

        BufferedImage channel2=new BufferedImage(spectralChannels[2].getWidth(),spectralChannels[2].getHeight(), BufferedImage.TYPE_INT_ARGB);
channel2.getGraphics().drawImage(spectralChannels[2],0,0,null);









       BufferedImage output=new BufferedImage(channel0.getWidth(), channel0.getHeight(), BufferedImage.TYPE_INT_ARGB);
    for (int x=0;x<spectralChannels[0].getWidth();x++)
        {
            for (int y=0;y<spectralChannels[0].getHeight();y++)
            {
                  int rgb = (channel2.getRGB(x, y) & 0x00FF0000) | (channel0.getRGB(x, y) & 0x0000FF00) | (channel1.getRGB(x, y) & 0x000000FF);

            output.setRGB(x, y, (rgb | 0xFF000000));
            }
        }
        ImageIO.write(output, "png", new File( "C:/Users/Karol/Desktop/Outred.png"));
        RGB=output;
        IsRGBCompiled=true;
        GUI_Window.setRGBButtonState(true); //allows to turn on RGB button in GUI
    }       
        
    
    
    public static BufferedImage [] getSpectralChannels()
{
    return spectralChannels;
}
   public static boolean getState()
   {
       return processed;
   }

   
   public static BufferedImage getRGB()
   {
       return RGB;
   }
    static void denoise(int amount, int radius) throws IOException
   {
        BoxBlurFilter blur = new BoxBlurFilter();
        blur.setRadius(radius);
        blur.setIterations(amount);
    tempDisp = blur.filter(tempDisp, tempDisp);
    GUI_Window.setImagePrev(tempDisp); //updates temp disp after blurring
   
   }
   
   public static void sharpen(int amount, int radius)
   {
         UnsharpFilter usf = new UnsharpFilter();
         usf.setAmount((float) amount); //sets amount of sharpening
         usf.setRadius(radius);
    tempDisp = usf.filter(tempDisp, tempDisp);
    GUI_Window.setImagePrev(tempDisp); //updates temp disp after blurring

   }
   
   static void resetToRaw() throws IOException
   {
  BufferedImage i = LoadImage.readImg(new File(RAWfilePath));
    GUI_Window.setImagePrev(Scalr.resize(i, Scalr.Method.SPEED, 650));
             Engine.setTempDisp(i); //passes the loaded image into Temp variable of Engine for processing
             Engine.AssembleFrames(i);  //assemble frames that are in engine after loading
   }
   
   static void setRAWFilePath(String s)
   {
       Engine.RAWfilePath=s;
       
   }
   
   static BufferedImage translateImage(int y, BufferedImage input) //function to translate image by Y pixels vertically, negative input is upwards
   {
    AffineTransform tx = new AffineTransform();
    tx.translate(0, y);

    AffineTransformOp op = new AffineTransformOp(tx,AffineTransformOp.TYPE_BILINEAR);
    input=op.filter(input, null);
    return input; 
   }
   
   
   public static boolean getRGBStatus()
   {
       return IsRGBCompiled;
   }
}
